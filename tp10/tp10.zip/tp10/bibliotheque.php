<?php
function panel_head($titre) {
    $panel = "<div class='panel panel-primary'>
                    <div class='panel-heading'>
                        <h2 class='panel-title'>$titre</h2>
                    </div>
                   </div>";
    return $panel;


}?>