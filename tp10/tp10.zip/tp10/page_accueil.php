<?php include "fragmenHeader.html";?>
<body>
    <div class="container">
        <?php
        include "fragmentMenu.html";
        include "fragmentJumbotron.html";
        include "fragmentFooter.html";
        ?>

    </div>

</body>
