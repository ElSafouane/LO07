<?php

header('Location: app/router/router1.php?action=truc');

?>

