 
<!-- ----- debut de la page cave_acceuil -->
<?php include 'fragment/fragmentCaveHeader.html'; ?>
<body>
  <div class="container">
    <?php
    include 'fragment/fragmentCaveMenu.html';
    include 'fragment/fragmentCaveJumbotron.html';
    ?>
  </div>   
  
  
  <?php
  include 'fragment/fragmentCaveFooter.html';
  ?>

  <!-- ----- fin de la page cave_acceuil -->

</body>
</html>